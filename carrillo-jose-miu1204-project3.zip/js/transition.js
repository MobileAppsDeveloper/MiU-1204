			$(document).bind("mobileinit", function(){
				$.mobile.defaultPageTransition = 'slidefade';
				$.mobile.defaultDialogTransition = 'flip';
			});